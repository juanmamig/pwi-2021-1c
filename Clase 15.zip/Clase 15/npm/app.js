const validator = require('validator');
console.log(validator.isEmail('juanmail.com'));