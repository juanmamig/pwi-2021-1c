// function requiree(module) {
//   if (module === 'fs') {
//     return {
//       name: 'Modulo FS'
//     };
//   }
// }

// const fs = requiree('fs');
// console.log(fs.name);