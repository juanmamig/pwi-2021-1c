console.log("Juan Ma");
const nombre = "Juan";
const apellido = "Migliore";

const saludar = function(_nombre){
  console.log("Hola " + _nombre)
}

module.exports = {
  nombre,
  apellido,
  saludar
};